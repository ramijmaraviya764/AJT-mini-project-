-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 11, 2025 at 09:37 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `track-my-class`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `roll_no` varchar(20) DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` enum('Present','Absent') DEFAULT NULL,
  `marked_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `roll_no`, `class`, `date`, `status`, `marked_by`) VALUES
(1, 'ENR2404', '4', '2025-11-10', 'Present', 4),
(2, 'ENR2402', '4', '2025-11-10', 'Present', 4),
(3, 'ENR2405', '4', '2025-11-10', 'Present', 4),
(4, 'student1', '4', '2025-11-10', 'Present', 4),
(5, 'student1', '4', '2025-11-10', 'Absent', 4);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_id` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `option_a` varchar(500) NOT NULL,
  `option_b` varchar(500) NOT NULL,
  `option_c` varchar(500) NOT NULL,
  `option_d` varchar(500) NOT NULL,
  `correct_option` enum('A','B','C','D') NOT NULL,
  `marks` int(11) DEFAULT 1,
  `teacher_id` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `marks`, `teacher_id`, `created_at`) VALUES
(1, 'What is the size of int in Java?', '8 bits', '16 bits', '32 bits', '64 bits', 'C', 5, '4', '2025-11-10 02:09:50'),
(2, 'Which keyword is used to create a class in Java?', 'class', 'Class', 'interface', 'extends', 'A', 5, '4', '2025-11-10 02:09:50'),
(3, 'What is the default value of boolean variable?', 'true', 'false', '0', 'null', 'B', 5, '4', '2025-11-10 02:09:50'),
(4, 'Which of these is not a Java feature?', 'Object-Oriented', 'Platform Independent', 'Use of pointers', 'Dynamic', 'C', 5, '4', '2025-11-10 02:09:50'),
(5, 'What is JVM?', 'Java Virtual Machine', 'Java Variable Method', 'Java Visual Mode', 'None of these', 'A', 5, '4', '2025-11-10 02:09:50');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `quiz_id` int(11) NOT NULL,
  `teacher_id` varchar(50) NOT NULL,
  `quiz_title` varchar(255) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `duration` int(11) DEFAULT 30 COMMENT 'Duration in minutes',
  `total_marks` int(11) DEFAULT 0,
  `instructions` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`quiz_id`, `teacher_id`, `quiz_title`, `subject`, `duration`, `total_marks`, `instructions`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '4', 'java', 'cs', 30, 25, 'type', 1, '2025-11-10 02:13:02', '2025-11-10 02:13:02');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_attempts`
--

CREATE TABLE `quiz_attempts` (
  `attempt_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `score` int(11) DEFAULT 0,
  `total_marks` int(11) DEFAULT 0,
  `percentage` decimal(5,2) DEFAULT 0.00,
  `time_taken` int(11) DEFAULT NULL COMMENT 'Time taken in minutes',
  `attempt_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_attempts`
--

INSERT INTO `quiz_attempts` (`attempt_id`, `quiz_id`, `student_id`, `score`, `total_marks`, `percentage`, `time_taken`, `attempt_date`) VALUES
(1, 1, '3', 10, 25, 40.00, 0, '2025-11-10 02:42:28');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_questions`
--

CREATE TABLE `quiz_questions` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question_order` int(11) DEFAULT 0,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_questions`
--

INSERT INTO `quiz_questions` (`id`, `quiz_id`, `question_id`, `question_order`, `added_at`) VALUES
(1, 1, 1, 0, '2025-11-10 02:13:02'),
(2, 1, 2, 0, '2025-11-10 02:13:02'),
(3, 1, 3, 0, '2025-11-10 02:13:02'),
(4, 1, 4, 0, '2025-11-10 02:13:02'),
(5, 1, 5, 0, '2025-11-10 02:13:02');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `dob` date NOT NULL,
  `standard` varchar(2) NOT NULL,
  `division` varchar(1) NOT NULL,
  `parent_name` varchar(100) NOT NULL,
  `parent_phone` varchar(15) NOT NULL,
  `enrollment_no` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_name`, `email`, `phone`, `dob`, `standard`, `division`, `parent_name`, `parent_phone`, `enrollment_no`, `address`, `password`, `created_at`, `updated_at`) VALUES
(4, 'Riya Patel', 'riya.patel@example.com', '9876543210', '2014-06-12', '4', 'A', 'Nirav Patel', '9876500011', 'ENR2401', '12, Green Park, Rajkot', 'riya123', '2025-11-09 17:56:50', '2025-11-09 17:56:50'),
(5, 'Karan Mehta', 'karan.mehta@example.com', '9876543221', '2014-04-25', '4', 'A', 'Rakesh Mehta', '9876500022', 'ENR2402', '20, Shakti Society, Rajkot', 'karan123', '2025-11-09 17:56:50', '2025-11-09 17:56:50'),
(6, 'Pooja Shah', 'pooja.shah@example.com', '9876543232', '2014-09-15', '4', 'A', 'Sanjay Shah', '9876500033', 'ENR2403', '8, Krishna Nagar, Rajkot', 'pooja123', '2025-11-09 17:56:50', '2025-11-09 17:56:50'),
(7, 'Aarav Joshi', 'aarav.joshi@example.com', '9876543243', '2014-03-09', '4', 'A', 'Ketan Joshi', '9876500044', 'ENR2404', '45, Patel Colony, Rajkot', 'aarav123', '2025-11-09 17:56:50', '2025-11-09 17:56:50'),
(8, 'Khushi Parmar', 'khushi.parmar@example.com', '9876543254', '2014-11-22', '4', 'A', 'Nilesh Parmar', '9876500055', 'ENR2405', '23, Shivaji Street, Rajkot', 'khushi123', '2025-11-09 17:56:50', '2025-11-09 17:56:50');

-- --------------------------------------------------------

--
-- Table structure for table `student_answers`
--

CREATE TABLE `student_answers` (
  `answer_id` int(11) NOT NULL,
  `attempt_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `selected_option` enum('A','B','C','D') DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT 0,
  `marks_obtained` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_answers`
--

INSERT INTO `student_answers` (`answer_id`, `attempt_id`, `question_id`, `selected_option`, `is_correct`, `marks_obtained`) VALUES
(1, 1, 1, 'A', 0, 0),
(2, 1, 2, 'A', 1, 5),
(3, 1, 3, 'A', 0, 0),
(4, 1, 4, 'A', 0, 0),
(5, 1, 5, 'A', 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `gr_number` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `standard` varchar(50) DEFAULT NULL,
  `qualification` varchar(150) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `user_id`, `gr_number`, `name`, `email`, `phone`, `dob`, `subject`, `standard`, `qualification`, `address`, `created_at`) VALUES
(1, 4, 764803, 'test', 'maraviyaramij@gmail.com', '8511895114', '2025-11-09', 'Science', '4', 'M.Ed', 'rajkot', '2025-11-09 16:21:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','teacher','student') NOT NULL,
  `full_name` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `full_name`, `email`, `created_at`) VALUES
(1, 'admin123', 'admin@123', 'admin', 'System Admin', 'admin@example.com', '2025-11-01 14:49:41'),
(2, 'teacher1', 'teach@123', 'teacher', 'John Smith', 'teacher@example.com', '2025-11-01 14:49:41'),
(3, 'ENR2401', 'stud@123', 'student', 'Alice Johnson', 'student@example.com', '2025-11-01 14:49:41'),
(4, '123456', '12345678', 'teacher', 'test', 'maraviyaramij@gmail.com', '2025-11-09 16:21:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`quiz_id`);

--
-- Indexes for table `quiz_attempts`
--
ALTER TABLE `quiz_attempts`
  ADD PRIMARY KEY (`attempt_id`);

--
-- Indexes for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_quiz_question` (`quiz_id`,`question_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `enrollment_no` (`enrollment_no`),
  ADD KEY `idx_standard` (`standard`),
  ADD KEY `idx_enrollment` (`enrollment_no`),
  ADD KEY `idx_email` (`email`);

--
-- Indexes for table `student_answers`
--
ALTER TABLE `student_answers`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quiz_attempts`
--
ALTER TABLE `quiz_attempts`
  MODIFY `attempt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student_answers`
--
ALTER TABLE `student_answers`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `teachers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
