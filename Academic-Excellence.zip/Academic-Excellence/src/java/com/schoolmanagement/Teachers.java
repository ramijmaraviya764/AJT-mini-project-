package com.schoolmanagement;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/Teachers")
public class Teachers extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // ✅ Database connection settings - તમારા database settings અહીં update કરો
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/track-my-class";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = ""; // તમારો MySQL password અહીં લખો

    // ✅ Gmail settings - તમારા email credentials અહીં update કરો
    private static final String FROM_EMAIL = "academicexcellence126@gmail.com";
    private static final String FROM_PASSWORD = "Vzpr iupq mhfu hiby"; // Gmail App Password

    // ✅ GET request redirect કરે છે JSP page પર
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("admin/teachers.jsp");
    }

    // ✅ POST request - Form submission handle કરે છે
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        // Form માંથી બધા values લો
        String teacherName = request.getParameter("teacherName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String dob = request.getParameter("dob");
        String subject = request.getParameter("subject");
        String standard = request.getParameter("standard");
        String qualification = request.getParameter("qualification");
        String address = request.getParameter("address");
        String password = request.getParameter("password");

        Connection con = null;
        PreparedStatement pstUser = null;
        PreparedStatement pstTeacher = null;
        ResultSet rs = null;

        try {
            // Step 1: MySQL Driver load કરો
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Step 2: Database connection બનાવો
            con = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            con.setAutoCommit(false); // Transaction start

            // Step 3: GR Number generate કરો
            int newGR = 764801;
            String grQuery = "SELECT MAX(id) AS lastId FROM users WHERE role='teacher'";
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery(grQuery);
            
            if (rs.next()) {
                int lastId = rs.getInt("lastId");
                if (lastId > 0) {
                    newGR = 764800 + lastId + 1;
                }
            }
            rs.close();
            stmt.close();

            // Step 4: Users table માં insert કરો (login માટે)
            String insertUser = "INSERT INTO users (username, password, role, full_name, email) VALUES (?, ?, ?, ?, ?)";
            pstUser = con.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS);
            pstUser.setString(1, String.valueOf(newGR)); // Username = GR Number ✅
            pstUser.setString(2, password); // Password
            pstUser.setString(3, "teacher"); // Role
            pstUser.setString(4, teacherName); // Full Name
            pstUser.setString(5, email); // Email
            
            int rowsUser = pstUser.executeUpdate();

            if (rowsUser > 0) {
                // Generated user_id લો
                ResultSet genKeys = pstUser.getGeneratedKeys();
                int userId = 0;
                if (genKeys.next()) {
                    userId = genKeys.getInt(1);
                }
                genKeys.close();

                // Step 5: Teachers table માં insert કરો (details માટે)
                String insertTeacher = "INSERT INTO teachers (user_id, gr_number, name, email, phone, dob, subject, standard, qualification, address, created_at) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                
                pstTeacher = con.prepareStatement(insertTeacher);
                pstTeacher.setInt(1, userId);
                pstTeacher.setInt(2, newGR);
                pstTeacher.setString(3, teacherName);
                pstTeacher.setString(4, email);
                pstTeacher.setString(5, phone);
                pstTeacher.setString(6, dob);
                pstTeacher.setString(7, subject);
                pstTeacher.setString(8, standard);
                pstTeacher.setString(9, qualification);
                pstTeacher.setString(10, address);
                pstTeacher.executeUpdate();

                // Transaction commit કરો
                con.commit();

                // Step 6: Email send કરો
                boolean emailSent = sendEmail(email, teacherName, String.valueOf(newGR), email, password);

                // Step 7: Success page બતાવો
                showSuccessPage(response, teacherName, newGR, email, emailSent);

            } else {
                con.rollback();
                throw new Exception("Failed to insert user in database");
            }

        } catch (Exception e) {
            // Error થયો તો rollback કરો
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            
            e.printStackTrace();
            
            // Error page બતાવો
            showErrorPage(response, e.getMessage());
            
        } finally {
            // બધા resources close કરો
            try {
                if (rs != null) rs.close();
                if (pstUser != null) pstUser.close();
                if (pstTeacher != null) pstTeacher.close();
                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // ✅ Success page display કરે છે
    private void showSuccessPage(HttpServletResponse response, String teacherName, int grNumber, String email, boolean emailSent) 
            throws IOException {
        response.getWriter().println("<!DOCTYPE html>");
        response.getWriter().println("<html><head><title>Success</title>");
        response.getWriter().println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        response.getWriter().println("<style>");
        response.getWriter().println("* { margin: 0; padding: 0; box-sizing: border-box; }");
        response.getWriter().println("body { font-family: 'Segoe UI', Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }");
        response.getWriter().println(".message-box { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 8px 32px rgba(0,0,0,0.2); text-align: center; max-width: 600px; width: 100%; animation: slideUp 0.5s ease; }");
        response.getWriter().println("@keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }");
        response.getWriter().println(".success-icon { font-size: 80px; margin-bottom: 20px; animation: bounce 1s ease; }");
        response.getWriter().println("@keyframes bounce { 0%, 20%, 50%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-20px); } 60% { transform: translateY(-10px); } }");
        response.getWriter().println("h1 { color: #10b981; margin-bottom: 15px; font-size: 28px; }");
        response.getWriter().println("p { color: #6b7280; margin: 10px 0; line-height: 1.6; font-size: 15px; }");
        response.getWriter().println(".info { background: #f9fafb; padding: 20px; border-radius: 10px; margin: 25px 0; border-left: 4px solid #10b981; }");
        response.getWriter().println(".info p { margin: 12px 0; text-align: left; }");
        response.getWriter().println(".info strong { color: #1f2937; display: inline-block; min-width: 140px; }");
        response.getWriter().println(".highlight { color: #667eea; font-weight: 700; }");
        response.getWriter().println(".email-status { padding: 15px; border-radius: 8px; margin: 20px 0; font-weight: 600; }");
        response.getWriter().println(".email-success { background: #d1fae5; color: #065f46; border-left: 4px solid #10b981; }");
        response.getWriter().println(".email-warning { background: #fef3c7; color: #92400e; border-left: 4px solid #f59e0b; }");
        response.getWriter().println(".btn-group { display: flex; gap: 15px; margin-top: 30px; flex-wrap: wrap; justify-content: center; }");
        response.getWriter().println(".btn { padding: 14px 30px; border: none; border-radius: 10px; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.3s ease; font-size: 15px; }");
        response.getWriter().println(".btn-primary { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }");
        response.getWriter().println(".btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4); }");
        response.getWriter().println(".btn-secondary { background: #6b7280; color: white; }");
        response.getWriter().println(".btn-secondary:hover { background: #4b5563; transform: translateY(-2px); }");
        response.getWriter().println("@media (max-width: 768px) { .message-box { padding: 30px 20px; } .btn-group { flex-direction: column; } .btn { width: 100%; justify-content: center; } }");
        response.getWriter().println("</style></head><body>");
        response.getWriter().println("<div class='message-box'>");
        response.getWriter().println("<div class='success-icon'>✓</div>");
        response.getWriter().println("<h1>Teacher Added Successfully!</h1>");
        response.getWriter().println("<p>The teacher has been registered in the system successfully.</p>");
        response.getWriter().println("<div class='info'>");
        response.getWriter().println("<p><strong>Teacher Name:</strong> <span class='highlight'>" + teacherName + "</span></p>");
        response.getWriter().println("<p><strong>GR Number:</strong> <span class='highlight'>" + grNumber + "</span></p>");
        response.getWriter().println("<p><strong>Email:</strong> <span class='highlight'>" + email + "</span></p>");
        response.getWriter().println("</div>");
        
        if (emailSent) {
            response.getWriter().println("<div class='email-status email-success'>");
            response.getWriter().println("✓ Login credentials have been successfully sent to the teacher's email address.");
            response.getWriter().println("</div>");
        } else {
            response.getWriter().println("<div class='email-status email-warning'>");
            response.getWriter().println("⚠ Email could not be sent. Please share the credentials manually with the teacher.");
            response.getWriter().println("</div>");
        }
        
        response.getWriter().println("<div class='btn-group'>");
        response.getWriter().println("<a href='admin/teachers.jsp' class='btn btn-primary'><span>➕</span> Add Another Teacher</a>");
        response.getWriter().println("<a href='admin/dashboard.jsp' class='btn btn-secondary'><span>🏠</span> Go to Dashboard</a>");
        response.getWriter().println("</div>");
        response.getWriter().println("</div></body></html>");
    }

    // ✅ Error page display કરે છે
    private void showErrorPage(HttpServletResponse response, String errorMessage) throws IOException {
        response.getWriter().println("<!DOCTYPE html>");
        response.getWriter().println("<html><head><title>Error</title>");
        response.getWriter().println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        response.getWriter().println("<style>");
        response.getWriter().println("* { margin: 0; padding: 0; box-sizing: border-box; }");
        response.getWriter().println("body { font-family: 'Segoe UI', Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }");
        response.getWriter().println(".message-box { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 8px 32px rgba(0,0,0,0.2); text-align: center; max-width: 600px; width: 100%; animation: slideUp 0.5s ease; }");
        response.getWriter().println("@keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }");
        response.getWriter().println(".error-icon { font-size: 80px; margin-bottom: 20px; color: #ef4444; }");
        response.getWriter().println("h1 { color: #ef4444; margin-bottom: 15px; font-size: 28px; }");
        response.getWriter().println("p { color: #6b7280; margin: 10px 0; line-height: 1.6; font-size: 15px; }");
        response.getWriter().println(".error-details { background: #fee2e2; padding: 20px; border-radius: 10px; margin: 25px 0; border-left: 4px solid #ef4444; text-align: left; }");
        response.getWriter().println(".error-details p { color: #991b1b; font-family: monospace; font-size: 13px; word-break: break-word; }");
        response.getWriter().println(".btn { padding: 14px 30px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; border-radius: 10px; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; margin-top: 20px; cursor: pointer; transition: all 0.3s ease; }");
        response.getWriter().println(".btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4); }");
        response.getWriter().println("</style></head><body>");
        response.getWriter().println("<div class='message-box'>");
        response.getWriter().println("<div class='error-icon'>✕</div>");
        response.getWriter().println("<h1>Error Adding Teacher</h1>");
        response.getWriter().println("<p>An error occurred while processing your request. Please try again.</p>");
        response.getWriter().println("<div class='error-details'>");
        response.getWriter().println("<p><strong>Error:</strong> " + errorMessage + "</p>");
        response.getWriter().println("</div>");
        response.getWriter().println("<a href='admin/teachers.jsp' class='btn'><span>🔄</span> Try Again</a>");
        response.getWriter().println("</div></body></html>");
    }

    // ✅ Email send કરે છે teacher ને
    private boolean sendEmail(String toEmail, String teacherName, String grNumber, String username, String password) {
        String subject = "🎓 Academic Excellence - Teacher Account Created";
        
        // HTML email template
        String msg = "<!DOCTYPE html>"
                + "<html><head><style>"
                + "body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }"
                + ".email-container { max-width: 600px; margin: 30px auto; background-color: white; border-radius: 15px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }"
                + ".header { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 30px 20px; text-align: center; }"
                + ".header h1 { margin: 0; font-size: 28px; }"
                + ".header p { margin: 10px 0 0 0; opacity: 0.95; font-size: 14px; }"
                + ".content { padding: 30px; }"
                + ".content h2 { color: #1f2937; font-size: 22px; margin-bottom: 15px; }"
                + ".content p { color: #4b5563; line-height: 1.6; margin: 12px 0; }"
                + ".credentials-box { background: #f9fafb; border-left: 4px solid #667eea; padding: 20px; margin: 25px 0; border-radius: 5px; }"
                + ".credentials-box p { margin: 12px 0; font-size: 15px; }"
                + ".credentials-box strong { color: #1f2937; display: inline-block; min-width: 120px; }"
                + ".credentials-box .value { color: #667eea; font-weight: 700; font-family: monospace; }"
                + ".warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; border-radius: 5px; }"
                + ".warning p { color: #92400e; margin: 0; font-weight: 600; }"
                + ".btn { display: inline-block; background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 14px 30px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }"
                + ".footer { background: #f9fafb; padding: 20px; text-align: center; border-top: 1px solid #e5e7eb; }"
                + ".footer p { color: #6b7280; font-size: 13px; margin: 5px 0; }"
                + "</style></head><body>"
                + "<div class='email-container'>"
                + "<div class='header'>"
                + "<h1>📚 Academic Excellence</h1>"
                + "<p>Welcome to Our Education Platform</p>"
                + "</div>"
                + "<div class='content'>"
                + "<h2>Dear " + teacherName + ",</h2>"
                + "<p>Congratulations! Your teacher account has been successfully created in the Academic Excellence management system.</p>"
                + "<p>You can now access the system using the credentials provided below:</p>"
                + "<div class='credentials-box'>"
                + "<p><strong>🆔 GR Number:</strong> <span class='value'>" + grNumber + "</span></p>"
                + "<p><strong>👤 Username:</strong> <span class='value'>" + username + "</span></p>"
                + "<p><strong>🔑 Password:</strong> <span class='value'>" + password + "</span></p>"
                + "</div>"
                + "<div class='warning'>"
                + "<p>⚠ <strong>Important:</strong> Please change your password after your first login for security purposes.</p>"
                + "</div>"
                + "<p>You can access the system by clicking the button below:</p>"
                + "<a href='http://localhost:8080/Academic-Excellence' class='btn'>🚀 Login to System</a>"
                + "<p>If you have any questions or need assistance, please don't hesitate to contact the administrator.</p>"
                + "<p style='margin-top: 30px;'>Best regards,<br><strong>Academic Excellence Admin Team</strong></p>"
                + "</div>"
                + "<div class='footer'>"
                + "<p>This is an automated email. Please do not reply to this message.</p>"
                + "<p>&copy; 2024 Academic Excellence. All rights reserved.</p>"
                + "</div>"
                + "</div></body></html>";

        // Gmail SMTP settings
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, FROM_PASSWORD);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM_EMAIL, "Academic Excellence"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);
            message.setContent(msg, "text/html; charset=utf-8");
            
            Transport.send(message);
            
            System.out.println("✓ Email sent successfully to: " + toEmail);
            return true;
            
        } catch (Exception e) {
            System.err.println("✕ Email sending failed: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}