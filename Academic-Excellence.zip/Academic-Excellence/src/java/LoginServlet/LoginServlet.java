package LoginServlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Database credentials
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/track-my-class";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = ""; // your password if any
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        // basic null check
        if (username == null || password == null || username.isEmpty() || password.isEmpty()) {
            response.getWriter().println("<script>alert('Please enter username and password!');history.back();</script>");
            return;
        }
        
        try {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to database
            Connection con = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            
            // SQL Query - Fetching id as well
            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                // Get user details from database
                int userId = rs.getInt("id");
                String role = rs.getString("role");
                String fullName = rs.getString("full_name");
                
                // Create Session
                HttpSession session = request.getSession();
                session.setAttribute("userId", String.valueOf(userId));  // Store user ID
                session.setAttribute("username", username);
                session.setAttribute("fullName", fullName);
                session.setAttribute("role", role);
                
                // Role-based redirection
                switch (role) {
                    case "admin":
                        response.sendRedirect("admin/index.jsp");
                        break;
                    case "teacher":
                        response.sendRedirect("teachers/index.jsp");
                        break;
                    case "student":
                        response.sendRedirect("student/index.jsp");
                        break;
                    default:
                        response.getWriter().println("<script>alert('Unknown role found. Contact admin!');history.back();</script>");
                }
            } else {
                // Invalid login
                response.getWriter().println("<script>alert('Invalid username or password!');history.back();</script>");
            }
            
            rs.close();
            ps.close();
            con.close();
            
        } catch (ClassNotFoundException e) {
            response.getWriter().println("<script>alert('MySQL JDBC Driver not found! Add mysql-connector-j.jar in WEB-INF/lib');history.back();</script>");
        } catch (SQLException e) {
            response.getWriter().println("<script>alert('Database connection error: " + e.getMessage().replace("'", "") + "');history.back();</script>");
        } catch (Exception e) {
            response.getWriter().println("<script>alert('Unexpected error: " + e.getMessage().replace("'", "") + "');history.back();</script>");
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().println("<script>alert('GET method not allowed! Use POST method.');history.back();</script>");
    }
}